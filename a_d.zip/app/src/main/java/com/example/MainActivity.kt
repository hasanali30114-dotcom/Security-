package com.example

import android.Manifest
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Main Activity for "A/D" application designed with OPPO ColorOS Aquamorphic theme.
 * Features device binding validation, real-time scrollable log monitoring,
 * foreground service activation with WakeLock, and network download workflows.
 */
class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"

        /**
         * Placeholder for the authorized OPPO A5 device ID.
         * Replace "dummy_id_replace_me" with your device's actual Secure.ANDROID_ID.
         */
        const val MY_SECURE_DEVICE_ID = "dummy_id_replace_me"
    }

    private lateinit var tvLogs: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var tvDeviceIdInfo: TextView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvWifiChip: TextView
    private lateinit var tvWakeLockChip: TextView
    private lateinit var tvServiceChip: TextView

    // ColorOS Interactive Buttons
    private lateinit var btnCheckNetwork: Button
    private lateinit var btnOpenDataSettings: Button
    private lateinit var btnRestartService: Button
    private lateinit var btnVerifyDevice: Button
    private lateinit var btnCopyLogs: Button
    private lateinit var btnClearLogs: Button

    private var activeDownloadId: Long = -1L
    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    // Notification permission launcher for Android 13+ (API 33+)
    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                logAction("Notification permission granted (ColorOS Notification System).")
            } else {
                logAction("Warning: Notification permission denied. Foreground notification may be suppressed.")
            }
            startForegroundServiceProcess()
        }

    // BroadcastReceiver for DownloadManager completion
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val downloadId = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (downloadId == activeDownloadId && activeDownloadId != -1L) {
                logAction("✔ [SUCCESS] Download completed successfully!")
                logAction("✔ Saved in: Movies/${NetworkHelper.DOWNLOAD_FOLDER}/${NetworkHelper.DOWNLOAD_FILE_NAME}")
                Toast.makeText(this@MainActivity, "A/D: Download Completed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI Elements & ColorOS Controls
        tvLogs = findViewById(R.id.tvLogs)
        scrollView = findViewById(R.id.scrollView)
        tvDeviceIdInfo = findViewById(R.id.tvDeviceIdInfo)
        tvStatusBadge = findViewById(R.id.tvStatusBadge)
        tvWifiChip = findViewById(R.id.tvWifiChip)
        tvWakeLockChip = findViewById(R.id.tvWakeLockChip)
        tvServiceChip = findViewById(R.id.tvServiceChip)

        btnCheckNetwork = findViewById(R.id.btnCheckNetwork)
        btnOpenDataSettings = findViewById(R.id.btnOpenDataSettings)
        btnRestartService = findViewById(R.id.btnRestartService)
        btnVerifyDevice = findViewById(R.id.btnVerifyDevice)
        btnCopyLogs = findViewById(R.id.btnCopyLogs)
        btnClearLogs = findViewById(R.id.btnClearLogs)

        logAction("==================================================")
        logAction("⚡ A/D SECURITY SUITE - COLOROS AQUAMORPHIC EDITION")
        logAction("==================================================")
        logAction("Initializing secure environment on OPPO A5 profile...")

        // Register DownloadManager completion receiver
        registerDownloadReceiver()

        // Configure ColorOS Button Click Listeners
        btnCheckNetwork.setOnClickListener {
            checkNetworkAndInitiateDownload()
        }

        btnOpenDataSettings.setOnClickListener {
            openMobileDataSettings()
        }

        btnRestartService.setOnClickListener {
            logAction("Re-triggering ADBackgroundService & WakeLock cycle...")
            startForegroundServiceProcess()
        }

        btnVerifyDevice.setOnClickListener {
            verifyDeviceBinding()
        }

        btnCopyLogs.setOnClickListener {
            copyLogsToClipboard()
        }

        btnClearLogs.setOnClickListener {
            tvLogs.text = ""
            logAction("Log console buffer cleared.")
        }

        // 1. Enforce Privacy & Device Binding Verification
        val isAuthorized = verifyDeviceBinding()
        if (!isAuthorized) {
            return
        }

        // 2. Request Notification Permission (Android 13+) and Start Foreground Service
        checkPermissionsAndStartService()

        // 3. Check Network and trigger download workflow
        checkNetworkAndInitiateDownload()
    }

    /**
     * Verifies the hardware ANDROID_ID against the authorized MY_SECURE_DEVICE_ID.
     */
    private fun verifyDeviceBinding(): Boolean {
        logAction("Scanning hardware Secure.ANDROID_ID...")
        val currentDeviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN"
        tvDeviceIdInfo.text = "HARDWARE ID: $currentDeviceId (OPPO A5)"

        val isMatching = (currentDeviceId == MY_SECURE_DEVICE_ID)
        val isPlaceholder = (MY_SECURE_DEVICE_ID == "dummy_id_replace_me")

        if (!isMatching && !isPlaceholder) {
            logAction("❌ [ACCESS DENIED] Unauthorized device detected!")
            logAction("❌ Detected Hardware: $currentDeviceId | Expected Binding: $MY_SECURE_DEVICE_ID")
            Toast.makeText(this, "Access Denied", Toast.LENGTH_SHORT).show()
            tvStatusBadge.text = "● BLOCKED"
            tvStatusBadge.setTextColor(0xFFFF5252.toInt())
            finish()
            return false
        } else if (isPlaceholder) {
            logAction("Hardware ID: $currentDeviceId")
            logAction("Notice: Active in Developer Setup Mode (MY_SECURE_DEVICE_ID = \"$MY_SECURE_DEVICE_ID\").")
            logAction("To bind exclusively to this OPPO A5, update MY_SECURE_DEVICE_ID = \"$currentDeviceId\".")
            logAction("✔ Device Verified (Setup Mode Active).")
            return true
        } else {
            logAction("✔ [VERIFIED] Device signature matched authorized OPPO A5 profile ($currentDeviceId).")
            return true
        }
    }

    /**
     * Requests POST_NOTIFICATIONS permission if required, then starts ADBackgroundService.
     */
    private fun checkPermissionsAndStartService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                startForegroundServiceProcess()
            } else {
                logAction("Requesting notification permission for ColorOS service bar...")
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            startForegroundServiceProcess()
        }
    }

    /**
     * Starts the Foreground Service (ADBackgroundService) with WakeLock support.
     */
    private fun startForegroundServiceProcess() {
        logAction("Starting Foreground Service (ADBackgroundService)...")
        val serviceIntent = Intent(this, ADBackgroundService::class.java).apply {
            action = ADBackgroundService.ACTION_START_SERVICE
        }

        try {
            ContextCompat.startForegroundService(this, serviceIntent)
            logAction("✔ Foreground Service active with low-priority notification.")
            logAction("✔ PowerManager.WakeLock (PARTIAL_WAKE_LOCK) engaged.")
            tvServiceChip.text = "SERVICE: ACTIVE"
            tvWakeLockChip.text = "WAKELOCK: ON"
        } catch (e: Exception) {
            logAction("❌ Error starting foreground service: ${e.localizedMessage}")
        }
    }

    /**
     * Validates network state and initiates download or displays Mobile Data prompt dialog.
     */
    fun checkNetworkAndInitiateDownload() {
        logAction("Checking network state...")
        val isWifi = NetworkHelper.isWifiConnected(this)
        val isCellular = NetworkHelper.isCellularConnected(this)
        val isAnyConnected = NetworkHelper.isConnected(this)

        if (isWifi) {
            tvWifiChip.text = "Wi-Fi: CONNECTED"
            logAction("✔ Wi-Fi Connected. High-bandwidth transfer available.")
            executeDownload()
        } else if (isCellular || isAnyConnected) {
            tvWifiChip.text = "DATA: CONNECTED"
            logAction("✔ Mobile Data / Cellular network active (Wi-Fi disconnected).")
            executeDownload()
        } else {
            tvWifiChip.text = "Wi-Fi: OFFLINE"
            logAction("⚠ Wi-Fi disconnected. No cellular network active.")
            logAction("Opening Mobile Data connection prompt dialog...")
            NetworkHelper.showWifiDisconnectedDialog(this) {
                logAction("Retrying network inspection...")
                checkNetworkAndInitiateDownload()
            }
        }
    }

    /**
     * Direct button handler to open mobile data / roaming settings.
     */
    private fun openMobileDataSettings() {
        logAction("Navigating to ColorOS Mobile Data / Roaming Settings...")
        val roamingIntent = Intent(Settings.ACTION_DATA_ROAMING_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(roamingIntent)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                startActivity(fallbackIntent)
            } catch (e2: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }
    }

    /**
     * Copies all real-time terminal logs to system clipboard.
     */
    private fun copyLogsToClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("A/D System Logs", tvLogs.text.toString())
        clipboard.setPrimaryClip(clip)
        logAction("📋 Logs copied to clipboard.")
        Toast.makeText(this, "Logs Copied to Clipboard", Toast.LENGTH_SHORT).show()
    }

    /**
     * Starts video download via DownloadManager.
     */
    private fun executeDownload() {
        logAction("Initiating DownloadManager task (${NetworkHelper.SAMPLE_VIDEO_URL})...")
        try {
            activeDownloadId = NetworkHelper.downloadSampleVideo(this)
            logAction("✔ Download enqueued. Reference ID: $activeDownloadId")
            logAction("Target: Movies/${NetworkHelper.DOWNLOAD_FOLDER}/${NetworkHelper.DOWNLOAD_FILE_NAME}")
        } catch (e: Exception) {
            logAction("❌ Download failed to initialize: ${e.localizedMessage}")
        }
    }

    /**
     * Appends a timestamped log entry to the real-time TextView monitor and auto-scrolls.
     */
    fun logAction(message: String) {
        val timestamp = timeFormatter.format(Date())
        val logEntry = "[$timestamp] $message\n"

        runOnUiThread {
            tvLogs.append(logEntry)
            scrollView.post {
                scrollView.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    private fun registerDownloadReceiver() {
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(
                this,
                downloadReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
        } else {
            registerReceiver(downloadReceiver, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(downloadReceiver)
        } catch (e: Exception) {
            // Receiver unregistration safety
        }
        super.onDestroy()
    }
}
