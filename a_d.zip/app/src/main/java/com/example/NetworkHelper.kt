package com.example

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.provider.Settings

/**
 * Helper object managing network state validation and secure download requests.
 */
object NetworkHelper {

    const val SAMPLE_VIDEO_URL = "https://www.w3schools.com/html/mov_bbb.mp4"
    const val DOWNLOAD_FOLDER = "A_D_Downloads"
    const val DOWNLOAD_FILE_NAME = "sample_video.mp4"

    /**
     * Checks if the device is currently connected to an active Wi-Fi network.
     */
    fun isWifiConnected(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Checks if the device has any working Internet connection (Wi-Fi, Cellular, Ethernet).
     */
    fun isConnected(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Checks if cellular data is connected.
     */
    fun isCellularConnected(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Displays a non-cancelable AlertDialog when Wi-Fi is disconnected,
     * prompting the user to activate mobile data settings.
     */
    fun showWifiDisconnectedDialog(
        context: Context,
        onRetry: () -> Unit
    ): AlertDialog {
        val dialog = AlertDialog.Builder(context)
            .setTitle("Wi-Fi Disconnected")
            .setMessage("Wi-Fi connection is currently offline. Please turn on Mobile Data / Data Roaming to continue uninterrupted transmission.")
            .setCancelable(false)
            .setPositiveButton("Turn on Mobile Data") { _, _ ->
                val roamingIntent = Intent(Settings.ACTION_DATA_ROAMING_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(roamingIntent)
                } catch (e: Exception) {
                    // Fallback to wireless settings if roaming intent is unsupported
                    val fallbackIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(fallbackIntent)
                    } catch (e2: Exception) {
                        // General settings fallback
                        context.startActivity(Intent(Settings.ACTION_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    }
                }
            }
            .setNegativeButton("Retry") { dialogInterface, _ ->
                dialogInterface.dismiss()
                onRetry()
            }
            .create()

        dialog.show()
        return dialog
    }

    /**
     * Enqueues a secure download of the sample video using Android DownloadManager.
     * Destination is set to Environment.DIRECTORY_MOVIES + "/A_D_Downloads".
     */
    fun downloadSampleVideo(context: Context, videoUrl: String = SAMPLE_VIDEO_URL): Long {
        val subPath = "$DOWNLOAD_FOLDER/$DOWNLOAD_FILE_NAME"

        val request = DownloadManager.Request(Uri.parse(videoUrl))
            .setTitle("A/D Secure Download")
            .setDescription("Downloading target sample payload: $DOWNLOAD_FILE_NAME")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, subPath)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)

        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return downloadManager.enqueue(request)
    }
}
